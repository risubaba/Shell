#include <sys/wait.h>
#include <sys/types.h>
#include <unistd.h>
#include <curses.h>
#include <stdio.h>
#include <string.h>

void executeCommand(char* ,char [1024][1024],int );
