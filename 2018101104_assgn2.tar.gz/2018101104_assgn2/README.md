## main.c
    Start shell and set directory

## builtIn.c
    Checks for the builtin commands and some extra commands

## executeCommand.c
    Executes commands not yet covered

## ls.c
    Contains code to perform ls function

## bonus.c
    Contains code for nightswatch and history

## pinfo.c
    Contains code for pinfo

